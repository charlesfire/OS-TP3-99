#pragma once
const int NB_CARTES = 3;